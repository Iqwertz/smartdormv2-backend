import json
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.middleware.csrf import get_token
from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.authentication import SessionAuthentication
from rest_framework.response import Response
from .permissions import GroupAndEmployeeTypePermission


@api_view(['GET'])
@permission_classes([IsAuthenticated, GroupAndEmployeeTypePermission])
@authentication_classes([SessionAuthentication])
def user_data_view(request):
    user_data_view.required_employee_types = ['TENANT']
    print(request.user)
    #Get user data and respond with userdata object
    
    return Response({"message": "Welcome to the netwerk dashboard!"})